const fs=require('fs');
const {Calc,selfTest}=new Function(fs.readFileSync(__dirname+'/../js/calc.js','utf8')+';return {Calc,selfTest}')();
const r=selfTest();r.forEach(t=>console.log(t[1]?'OK  ':'GAGAL',t[0]));
const za=Calc.rows(16,[{k:'N',dose:250,pct:46},{k:'S',dose:50,pct:24}],{g:100,n:21,s:24});
console.log(Math.abs(za[0].rem-0.379)<1e-9?'OK  ':'GAGAL','N sisa setelah 100 g ZA = 0,379 kg');
console.log(isNaN(Calc.produk(1,0))&&isNaN(Calc.germ(0,0))?'OK  ':'GAGAL','pembagian dengan nol aman');
process.exit(r.every(t=>t[1])?0:1);
