R.dash=()=>{const avg=S.kec.length?S.kec.reduce((a,k)=>a+Calc.germ(k.uji,k.kecambah),0)/S.kec.length:0;
 const luas=S.lahan.reduce((a,l)=>a+l.luas,0),koms=new Set(S.lahan.filter(l=>l.status=='Aktif').map(l=>l.kom)).size;
 const tp=S.tumbuh.map(t=>({l:t.tgl,v:t.tinggi})),nx=S.giat.filter(g=>g.tgl>=today()).sort((a,b)=>a.tgl>b.tgl?1:-1)[0];
 M.innerHTML=head('Selamat datang, Sahabat Tani 👋','Asisten digital budidaya pertanian')+simBadge+`
 <div class="grid">${[['Total lahan',fmt(luas)+' m² ('+fmt(luas/10000,3)+' ha)'],['Komoditas aktif',koms],['Kegiatan tercatat',S.giat.length],['Rata-rata perkecambahan',fmt(avg,1)+'%']].map(s=>`<div class="card stat"><b>${s[1]}</b><span>${s[0]}</span></div>`).join('')}</div>
 <div class="card np"><b>Aksi cepat</b><br>${[['pupuk','Hitung Kebutuhan Pupuk'],['lahan','Tambah Data Tanaman'],['kec','Hitung Perkecambahan'],['tumbuh','Catat Pertumbuhan'],['keluh','Sampaikan Keluhan']].map(a=>`<button class="btn" onclick="go('${a[0]}')">${a[1]}</button>`).join('')}</div>
 <div class="grid"><div class="card"><b>Grafik tinggi tanaman (cm)</b>${line(tp,'cm')}</div>
 <div class="card"><b>Jadwal berikutnya</b><p>${nx?`${nx.tgl} — ${esc(nx.jenis)}`:'Belum ada jadwal'}</p><small class="sub">Pengingat hanya tampil di aplikasi ini (belum ada layanan notifikasi).</small>
 <b>Ringkasan kebutuhan pupuk</b><p>${S.hitung.length?S.hitung.length+' perhitungan tersimpan; terakhir: '+esc(S.hitung.at(-1).lahan):'Belum ada perhitungan tersimpan'}</p></div></div>
 <div class="card"><b>Keluhan terbaru</b>${tbl(['Tanggal','Kategori','Komoditas','Status'],S.keluhan.slice(-4).reverse().map(k=>[k.tgl,k.kat,k.kom,`<span class="tag">${k.status}</span>`]))}</div>`};
