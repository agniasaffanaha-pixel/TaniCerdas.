/* ===== modul kalkulasi (murni, dapat diuji) ===== */
const Calc={
 hara:(dose,m2)=>dose*m2/10000,
 produk:(kg,pct)=>pct>0?kg/(pct/100):NaN,
 kandungan:(prodKg,pct)=>prodKg*pct/100,
 germ:(u,k)=>u>0?k/u*100:NaN,
 hidup:(a,b)=>a>0?b/a*100:NaN,
 prod:(kg,ha)=>ha>0?kg/ha:NaN,
 /* za:{g,n,s} gram ZA dan kadar N,S (%) -> dikurangkan dari kebutuhan N dan S */
 rows(m2,rows,za){const zn=za.g/1000*za.n/100,zs=za.g/1000*za.s/100;
  return rows.map(r=>{const need=Calc.hara(r.dose,m2);let sup=0;if(r.k=='N')sup=zn;if(r.k=='S')sup=zs;
   const rem=Math.max(0,need-sup),pk=Calc.produk(rem,r.pct);return{...r,need,sup,rem,kg:pk,g:pk*1000,over:sup>need+1e-12}})}
};
function selfTest(){const r=Calc.rows(16,[{k:'N',dose:250,pct:46},{k:'P',dose:300,pct:36},{k:'K',dose:150,pct:60}],{g:0,n:21,s:24});
 const t=[['Kebutuhan N 0,4 kg',r[0].need,.4],['Urea 869,57 g',r[0].g,869.565],['P₂O₅ 0,48 kg',r[1].need,.48],['SP-36 1333,33 g',r[1].g,1333.333],['K₂O 0,24 kg',r[2].need,.24],['KCl 400 g',r[2].g,400],['Germinasi 85/100',Calc.germ(100,85),85]];
 return t.map(x=>[x[0],Math.abs(x[1]-x[2])<0.01]);}
