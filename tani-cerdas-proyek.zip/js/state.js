const $=id=>document.getElementById(id),nav=$('nav'),M=$('m');
const fmt=(n,d=2)=>Number(n).toLocaleString('id-ID',{maximumFractionDigits:d});
const today=()=>new Date().toISOString().slice(0,10);
let mem=null;const KEY='tanicerdas_v1';
const seed=()=>({lahan:[{id:1,nama:'Petak A (simulasi)',lokasi:'Bogor',luas:16,tanah:'Latosol',kom:'Cabai',var:'Rawit',tgl:'2026-08-01',status:'Aktif'},{id:2,nama:'Sawah Blok 2 (simulasi)',lokasi:'Cianjur',luas:5000,tanah:'Aluvial',kom:'Padi',var:'Inpari',tgl:'2026-07-15',status:'Aktif'}],
hitung:[],kec:[{id:1,tgl:'2026-08-02',kom:'Cabai',var:'Rawit',uji:100,kecambah:85,cat:'Data simulasi'}],
tumbuh:[7,14,21,28,35].map((d,i)=>({id:i+1,lahan:'Petak A (simulasi)',tgl:'2026-08-'+String(d+1).padStart(2,'0'),awal:20,hidup:20-(i>2?1:0),tinggi:[5,11,19,28,36][i],kond:'Sehat',hama:0})),
panen:[],giat:[{id:1,tgl:'2026-10-08',jenis:'Pemupukan',biaya:15000,jumlah:'400 g KCl',cat:'Jadwal contoh (simulasi)'}],
keluhan:[{id:1,nama:'Anonim',kom:'Cabai',kat:'Daun menguning',desk:'Daun bawah menguning sejak 3 hari (simulasi).',status:'Menunggu tanggapan',tgl:'2026-09-28',resp:[]}],bk:{baik:85,sedang:70}});
let S;try{S=JSON.parse(localStorage.getItem(KEY))}catch(e){}S=S||seed();
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
const nid=a=>a.reduce((x,y)=>Math.max(x,y.id),0)+1;
const v=id=>$(id).value.trim(),n=id=>parseFloat($(id).value);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const inp=(id,l,t='text',x='')=>`<div><label for="${id}">${l}</label><input id="${id}" type="${t}" ${x}></div>`;
const sel=(id,l,o,x='')=>`<div><label for="${id}">${l}</label><select id="${id}" ${x}>${o.map(a=>`<option>${esc(a)}</option>`).join('')}</select></div>`;
const KOM=['Padi','Jagung','Cabai','Tomat','Bawang merah','Kentang','Kedelai','Sayuran daun','Lainnya'];
const lahanOpts=()=>S.lahan.map(l=>l.nama);
