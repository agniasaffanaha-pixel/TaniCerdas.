/* ===== router ===== */
const P=[['dash','🏠 Dashboard'],['pupuk','🧪 Kalkulator Pupuk'],['kec','🌱 Perkecambahan'],['tumbuh','📈 Pemantauan Tanaman'],['eval','✅ Evaluasi Budidaya'],['kal','📅 Kalender Budidaya'],['keluh','💬 Keluhan Petani'],['lahan','🗺 Manajemen Lahan'],['lap','🖨 Laporan'],['set','⚙ Pengaturan']];
function go(p){nav.classList.remove('open');location.hash=p;R[p]();nav.querySelectorAll('a').forEach(a=>a.classList.toggle('on',a.dataset.p==p));scrollTo(0,0)}
nav.innerHTML='<h1>🌾 TANI CERDAS</h1><small>Hitung Tepat, Pantau Tanaman, Tingkatkan Hasil Panen.</small>'+P.map(a=>`<a data-p="${a[0]}" onclick="go('${a[0]}')">${a[1]}</a>`).join('');
const head=(t,s)=>`<h2>${t}</h2><p class="sub">${s}</p>`;
const R={};
