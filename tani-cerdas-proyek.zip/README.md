# TANI CERDAS — Asisten Digital Budidaya Pertanian

Hitung Tepat, Pantau Tanaman, Tingkatkan Hasil Panen.

## Cara menjalankan
Buka `index.html` di browser (klik dua kali). Tidak perlu instalasi.
Untuk online: unggah `index.html` ke hosting statis (Netlify, GitHub Pages, dll).

## Catatan
- Semua data disimpan di browser (localStorage). Data contoh adalah data simulasi.
- Di luar claude.ai, aplikasi berjalan dalam mode lokal: tidak ada login, keluhan tidak dibagikan antar pengguna.
- Fitur login Google, database online, dan unggah foto membutuhkan backend (mis. Supabase/Firebase) yang belum disertakan.
- Rumus kalkulator ada pada objek `Calc`; uji rumus otomatis ada di menu Pengaturan.
- Dosis pada kalkulator hanyalah contoh uji hitung, bukan rekomendasi agronomis. Sesuaikan dengan analisis tanah dan penyuluh.

## Struktur
- `index.html` — kerangka halaman, memuat semua skrip
- `css/style.css` — tema dan tata letak responsif
- `js/state.js` — data, penyimpanan, helper formulir
- `js/calc.js` — rumus pupuk, perkecambahan, kelangsungan hidup, produktivitas
- `js/ui.js` — grafik SVG dan tabel
- `js/router.js` — navigasi sidebar / menu mobile
- `js/pages/` — satu berkas per halaman: dashboard, pupuk, perkecambahan, pertumbuhan, evaluasi, kalender, keluhan, lahan, laporan, pengaturan
- `js/main.js` — inisialisasi
- `tests/calc.test.js` — uji rumus: `node tests/calc.test.js`
